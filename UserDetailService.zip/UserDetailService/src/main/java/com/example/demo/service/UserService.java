package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Role;
import com.example.demo.model.Technology;
import com.example.demo.model.User;
import com.example.demo.model.UserCompletedTraining;
import com.example.demo.model.UserCurrentTraining;
import com.example.demo.model.UserDetails;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.TechnologyRepository;
import com.example.demo.repository.UserCompletedRepository;
import com.example.demo.repository.UserCurrentRepository;
import com.example.demo.repository.UserDetailsRepository;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserCompletedRepository usercompletedRepository;
	@Autowired
	private UserCurrentRepository usercurrentRepository;
	@Autowired
	private UserDetailsRepository userdetailsRepository;
	@Autowired
	private TechnologyRepository technologyRepository;
	
	
	public void saveRole(Role r) {
		roleRepository.save(r);
		
	}
	
	public void saveUserDetails(UserDetails u) {
		userdetailsRepository.save(u);
		
		
	}
	public void saveUser(User u) {
		userRepository.save(u);
	}
	public User findUser(String username) {
		return userRepository.findByUsername(username);
	}
	public List<UserCompletedTraining> searchCompleted(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return usercompletedRepository.findByUsername(u);
		
	}
	public List<UserCurrentTraining> searchCurrent(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return usercurrentRepository.findByUsername(u);
		
	}
	public void savecurrent(String username,String technology) {
		Technology t=technologyRepository.findByTechnology(technology);
		User user=userRepository.findByUsername(username);
		UserCurrentTraining u=new UserCurrentTraining();
		u.setTechnology(t.getTechnology());
		u.setPendingduration(t.getDuration());
		u.setCompletedduration("0Days");
		u.setUsername(user);
		usercurrentRepository.save(u);
	}
	

}
