package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Mentor;
import com.example.demo.model.MentorCompletedTraining;
import com.example.demo.model.MentorCurrentTraining;
import com.example.demo.model.User;
import com.example.demo.service.MentorService;



@RefreshScope
@RestController
@CrossOrigin(origins="http://localhost:4200")
public class MainController {
	@Autowired
	private MentorService mentorservice;
	
	@Autowired
	   RestTemplate restTemplate;

	   @GetMapping("/savetechnology")
	   public String savetechnology(@PathVariable String username,@PathVariable String technology) {
	      HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      return restTemplate.exchange("http://localhost:8080/api/course/savetechnology/"+username+"/"+technology, HttpMethod.GET, entity, String.class).getBody();
	   }
	   
	   @GetMapping("/savetime")
	   public String savetime(@PathVariable String username,@PathVariable String time) {
	      HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      return restTemplate.exchange("http://localhost:8080/api/course/savetime/"+username+"/"+time, HttpMethod.GET, entity, String.class).getBody();
	   }
	   @GetMapping("/findskill")
	   public String findskill(@PathVariable String username) {
	      HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      return restTemplate.exchange("http://localhost:8080/api/course/findskill/"+username, HttpMethod.GET, entity, String.class).getBody();
	   }
	
		@GetMapping("/findmentor/{username}")
	public @ResponseBody Mentor findMentor(@PathVariable String username) {
		return mentorservice.findMentor(username);
	}
	
	@PostMapping("/save")
	public @ResponseBody String saveUser(@RequestBody Mentor m){
		mentorservice.saveMentorDetails(m);
		return "stored";
	}
	@PostMapping("/savementor")
	public @ResponseBody String savementor(@RequestBody User u){
		mentorservice.saveMentor(u);
		return "stored";
	}
	
	
	@GetMapping("/findcompleted/{username}")
	public @ResponseBody List<MentorCompletedTraining>  findcompleted(@PathVariable String username){
		
return mentorservice.searchCompleted(username);
	}
	@GetMapping("/findcurrent/{username}")
	public @ResponseBody List<MentorCurrentTraining>  findcurrent(@PathVariable String username){
		
return mentorservice.searchCurrent(username);
	}

}
