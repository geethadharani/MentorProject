package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Mentor;
import com.example.demo.model.MentorCompletedTraining;
import com.example.demo.model.MentorCurrentTraining;

import com.example.demo.model.Role;
import com.example.demo.model.User;

import com.example.demo.repository.MentorCompletedTrainingRepository;
import com.example.demo.repository.MentorCurrentTrainingRepository;
import com.example.demo.repository.MentorRepository;

import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;

@Service
public class MentorService {
	
	@Autowired
	private MentorRepository mentorRepository;
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private MentorCompletedTrainingRepository mentorCompletedRepository;
	@Autowired
	private MentorCurrentTrainingRepository mentorCurrentRepository;
	
	
	
	public void saveMentorDetails(Mentor m) {
		mentorRepository.save(m);
		
		
	}
	public void saveMentor(User u) {
		userRepository.save(u);
		
		
	}
	
	
	public List<MentorCompletedTraining> searchCompleted(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return mentorCompletedRepository.findByUsername(u);
		
	}
	public List<MentorCurrentTraining> searchCurrent(String username) {
		User u=userRepository.findByUsername(username);
		
		
		return mentorCurrentRepository.findByUsername(u);
		
	}
	
	
	public Mentor findMentor(String username) {
		return mentorRepository.findByUsername(username);
	}
	

}
