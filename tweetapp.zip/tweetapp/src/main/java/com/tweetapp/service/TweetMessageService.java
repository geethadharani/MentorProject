package com.tweetapp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.entity.TweetMessage;
import com.tweetapp.entity.UserRegistration;
import com.tweetapp.repository.TweetMessageRepository;
import com.tweetapp.repository.UserRegistrationRepository;

@Service
public class TweetMessageService {
	@Autowired
	TweetMessageRepository tweetMessageRepository;
	@Autowired
	UserRegistrationRepository userRegistrationRepository;
	
	public List<TweetMessage> getAllTweet() {
		return tweetMessageRepository.findAll();
		
	}
	public String postTweet(TweetMessage tweetMessage,String username) {
		
		tweetMessage.setLoginId(username);
		tweetMessageRepository.save(tweetMessage);
		return "saved";
	}
	public List<TweetMessage> getUserTweet(String username) {
		//tweetMessageRepository.=
		return tweetMessageRepository.findByLoginId(username);
		
	}
	public String updateTweetMessage(String username,String id,String tweet) {
		TweetMessage tweetMessage=tweetMessageRepository.findByIdAndLoginId(id, username);
	    tweetMessage.setTweetMessage(tweet);
		tweetMessageRepository.save(tweetMessage);
				return "updated";
	}
	public String deleteTweetMessage(String username,String id) {
		tweetMessageRepository.deleteByIdAndLoginId(id, username);
				return "deleted";
	}
	

}
