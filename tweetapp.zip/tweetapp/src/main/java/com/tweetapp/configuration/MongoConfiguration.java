package com.tweetapp.configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

@Configuration
@EnableAutoConfiguration
public class MongoConfiguration extends AbstractMongoClientConfiguration {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${spring.data.mongodb.database}")
	private String databaseName;

	@Value("${spring.data.mongodb.uri}")
	private String uri;

	public @Bean MongoClient mongoClient() {
		logger.info("Creating MongoClient");
		return MongoClients.create(uri);
	}

	public @Bean MongoTemplate mongoTemplate() {
		logger.info("Creating Mongotemplate");
		return new MongoTemplate(mongoClient(), databaseName);
	}

	@Bean
	MongoTransactionManager transactionManager(MongoDatabaseFactory dbFactory) {
		return new MongoTransactionManager(dbFactory);
	}

	@Override
	protected String getDatabaseName() {
		return "database";
	}
}