package com.tweetapp.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import com.tweetapp.entity.UserRegistration;
@Repository
public interface UserRegistrationRepository extends MongoRepository<UserRegistration, String>{
 public UserRegistration findByLoginId(String username);
 public UserRegistration findByLoginIdAndEmail(String username,String email);
 
}
