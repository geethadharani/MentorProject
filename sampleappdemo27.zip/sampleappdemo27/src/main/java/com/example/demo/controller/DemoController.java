package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.example.demo.entity.User;
import com.example.demo.entity.UserDetails;
import com.example.demo.repository.DemoRepo;
import com.example.demo.repository.UserDetailsRepository;

@RestController
public class DemoController {
	@Autowired
	DemoRepo repo;
	@Autowired
	UserDetailsRepository userrepo;
	
	Logger logger = LoggerFactory.getLogger(DemoController.class);
	@RequestMapping(value="/getData")
	public String getdata() {
		logger.info("first");
		return "Good Morning-Hello";
	}
	@RequestMapping(value="")
	public String getdata1() {
		logger.info("first");
		return "WELCOME";
	}
	@RequestMapping(value="/getUser")
	public List<User> getUser() {
		logger.info("second");
		return (List<User>) repo.findAll();
	}
	@RequestMapping(value="/getUserDetails")
	public List<UserDetails> getUserDetails() {
		logger.info("second");
		return (List<UserDetails>) userrepo.findAll();
	}

}
