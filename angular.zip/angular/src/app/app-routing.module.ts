import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UsersignupComponent } from './usersignup/usersignup.component';

import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';

import { UsermenuComponent } from './usermenu/usermenu.component';
import { HomeComponent } from './home/home.component';
import { MentormenuComponent } from './mentormenu/mentormenu.component';
import { AdminmenuComponent } from './adminmenu/adminmenu.component';
import { ProfileComponent } from './profile/profile.component';
import { LogoutComponent } from './logout/logout.component';


const routes: Routes = [{path:'',component:HomeComponent},{path:'userlogin',component:UserloginComponent},{path:'usersignup',component:UsersignupComponent},
{path:'mentorsignup',component:MentorsignupComponent},
{path:'usermenu/:username',component:UsermenuComponent},
{path:'mentormenu/:username',component:MentormenuComponent},{path:'adminmenu/:username',component:AdminmenuComponent},
{path:'profile',component:ProfileComponent},{path:'logged',component:LogoutComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
