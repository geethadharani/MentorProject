export class Mentor{
    username:string;
    contactnumber:number;
    experience:string;
    facilities:string;
    firstname:string;
    lastname:string;
}