import { Mentor } from './mentorsignup';

export class Mentortime{
    time:string;
    id:string;
    mentor:Mentor;
}