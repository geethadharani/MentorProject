import { Mentor } from './mentorsignup';

export class Mentortechnology{
    technology:string;
    id:string;
    mentor:string;
}