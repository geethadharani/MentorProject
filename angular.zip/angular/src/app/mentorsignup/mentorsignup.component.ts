import { Component, OnInit } from '@angular/core';
import { MentorserviceService } from '../mentorservice.service';

import { Mentor } from './mentorsignup';
import { Mentortime } from './mentortime';
import { Mentortechnology } from './mentortechnology';
import { Userregister } from '../usersignup/userregister';
import { Role } from '../usersignup/role';


export class Mentortech{
  id:number;
  technology:string;
}

 

@Component({
  selector: 'app-mentorsignup',
  templateUrl: './mentorsignup.component.html',
  styleUrls: ['./mentorsignup.component.css']
})
export class MentorsignupComponent implements OnInit {
  private dropdownListtechnology = [];
  private dropdownListtime = [];
  private technology=[];
  private time=[];
  private display:boolean=true;
  private displayvalue:boolean=false;
  
 private dropdownSettings = {};
 private dropdownSettingstime = {};
 role:Role=new Role();
 private id=3;
 private rolename="mentor";
user:Userregister=new Userregister();
mentor:Mentor=new Mentor();
mentortime:Mentortime=new Mentortime();
mentortechnology:Mentortechnology=new Mentortechnology();
private submitted = false;
private error = false;
  username:string;
password:string;

firstname:string;
lastname:string;
contactnumber:number;
facilities:string;
experience:string;

  constructor(private mentorservice:MentorserviceService) { }

  ngOnInit() {
    this.dropdownListtime=[
      {"id":1,"time":"8AM-10AM"},
      {"id":2,"time":"10AM-12PM"},
      {"id":3,"time":"2PM-4PM"},
    ]
  
   this.mentorservice.getTechnology().subscribe(data=>this.dropdownListtechnology=data as string[]);
    
    this.dropdownSettings= {
      singleSelection: false,
      idField: 'id',
      textField: 'technology',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      
      allowSearchFilter: true
    };
    this.dropdownSettingstime= {
      singleSelection: false,
      idField: 'id',
      textField: 'time',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
     
      allowSearchFilter: true
    };
  }
 

  save(){
    
    if(this.username==null || this.password==null || this.firstname==null || this.lastname==null
      || this.contactnumber==null || this.facilities==null || this.experience==null){
        this.error=true;
      }
    else{
      this.mentor.username=this.username;
    this.mentor.firstname=this.firstname;
    this.mentor.lastname=this.lastname;
    this.mentor.contactnumber=this.contactnumber;
    this.mentor.facilities=this.facilities;
    this.mentor.experience=this.experience;
    this.user.password=this.password;
    this.user.username=this.username;
    this.role.id=this.id;
    this.role.role=this.rolename;
    this.user.role=this.role;
    this.mentorservice.savementor(this.mentor).subscribe(data => console.log(data), error => console.log(error));
   this.mentorservice.savementorlogin(this.user).subscribe(data => console.log(data), error => console.log(error));
   this.display=false;
   this.displayvalue=true;
   this.error=false;
    }
    
  }
  store(){
    for (let i of this.technology) {
      
      this.mentorservice.savetechnology(this.mentor.username,i.technology).subscribe(data => console.log(data), error => console.log(error));
    }
    for (let j of this.time) {
      
      this.mentorservice.savetime(this.mentor.username,j.time).subscribe(data => console.log(data), error => console.log(error));
    }

    this.submitted = true;


  }
  onItemSelect(items: any) {
    this.technology.push(items);
    
    console.log(this.technology);
  }
  onItemSelecttime(items: any) {
    this.time.push(items);
    
    console.log(this.technology);
  }
  onSelectAll(items: any) {
    this.technology=items;
    
    console.log(this.technology);
  }
  onSelectAlltime(items: any) {
    this.time=items;
    
    console.log(this.time);
  }

  }


