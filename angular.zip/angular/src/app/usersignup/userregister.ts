import { Role } from './role';


export class Userregister{
    username:string;
    password:string;
    role:Role;
}