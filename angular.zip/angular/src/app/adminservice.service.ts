import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {
  private baseUrl = 'http://localhost:8080/api'; 

  constructor(private http:HttpClient) { }


  getPayment(){
    return this.http.get(`${this.baseUrl}/admin/findpayment`);

  }
  getTechnology():Observable<any> {  
    return this.http.get(`${this.baseUrl}/admin/findadmintechnology`);  
  }
  getUser(){  
    return this.http.get(`${this.baseUrl}/admin/finduser`);  
  }
  getMentor() {  
    return this.http.get(`${this.baseUrl}/admin/findmentor`);  
  }
  userblock(username:string){
    return this.http.get(`${this.baseUrl}/admin/userblock/${username}`);

  }
  userunblock(username:string){
    return this.http.get(`${this.baseUrl}/admin/userunblock/${username}`);

  }
  addtechnology(technology:string,duration:string){
    return this.http.get(`${this.baseUrl}/admin/savetechnology/${technology}/${duration}`);

  }
}
